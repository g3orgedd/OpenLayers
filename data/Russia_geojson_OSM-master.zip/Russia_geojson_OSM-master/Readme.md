
Here is the pack of Russian regions districts map in GeoJSON(Admin_Level=6).All what I've parsed with the help of OSM API (https://nominatim.openstreetmap.org/) and some Python code.
